import 'egg';

declare module 'egg' {

}