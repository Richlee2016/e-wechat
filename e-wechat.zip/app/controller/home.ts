import { Controller } from 'egg';
import {Contro,Get} from '../router'

@Contro('')
export default class HomeController extends Controller {
  @Get('name')
  public async index() {
    const { ctx } = this;
    ctx.body = await ctx.service.test.sayHi('egg');
  }
  @Get('home')
  public async home() {
    const { ctx } = this;
    ctx.body = await ctx.service.test.sayHi('egg');
  }
}
