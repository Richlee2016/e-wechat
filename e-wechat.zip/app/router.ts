import { Application } from 'egg';

let MapRouter:any = []
const box:any = [
  {
    controller:'home',
    path:'Home',
    methods:[
      {
        name:'index',
        path:'name',
        method:'get',
        middleware:function(){}
      }
    ]
  }
]
console.log(box);
export default (app: Application) => {
  const { controller, router } = app;
  router.get('/', controller.home.index);
};

const getControllerName = (name):string => {
  let controller:string = /(.+)Controller/.test(name)?RegExp.$1 : name
  return controller.toLowerCase()
}

export const Contro= (path:string) => (target) => {
  let cname = getControllerName(target.name)
  MapRouter.forEach(o => {
    if(o.name = cname){
      o.path = path
    }
  })
  console.log('controller====>>>>>>>>>',JSON.stringify(MapRouter));
}

export const Get = (path:string) =>(target,name) => {
  let cname = getControllerName(target.constructor.name)
  const isExist = MapRouter.some(o => o.name === cname)
  if(isExist){
    MapRouter.forEach(o => {
      if(o.name === cname){
        o.methods.push({
            name,
            path:path,
            method:'get',
            middleware:function(){}
        })
      }
    })
  }else{
    MapRouter.push({
      name:cname,
      methods:[
        {
          name,
          path:path,
          method:'get',
          middleware:function(){}
        }
      ]
    })
  }
  
  console.log('themap ======>>>>>',MapRouter);
}